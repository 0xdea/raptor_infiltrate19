#pulls all the files into a directory


echo "Pulling all files into suid directory"
mkdir suid
#mudge find command for portability
#comment out this to not do the find
find / -type f \( -perm -4000 -o -perm -02000 \) -exec ls -ld {} \; > find.out
#old find version
#find / -perm -4000 -ls > find.out
#old way needs this line: BOB=`cat ./find.out | awk '{print $11}'`
BOB=`cat ./find.out | awk '{print $9}'`
for i in $BOB; do echo $i; cp $i suid/; done
chmod -s suid/*
chmod a+rx suid/*
echo "done"
