Sharefuzz is a quick and dirty way to instrument a binary file that
supports loading a shared library. Currently, the provided example
displays all used environment variables, and attempts to set them to a
large invalid value to demonstrate overflows. This is a very fast way
to find most of the exploitable environment variable overflows on a
new system. 

To use:

./pullfiles.sh
make
LD_PRELOAD=./libd.so.1 suid/<name of file> <arguments>

For questions, comments, etc, e-mail Dave Aitel at daitel@atstake.com

All files covered under the GNU PUBLIC LICENSE v 2.0


